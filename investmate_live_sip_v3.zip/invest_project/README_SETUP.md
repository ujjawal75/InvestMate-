# InvestMate — Setup (Updated)

## 1) Create / activate venv
macOS:
```bash
python3 -m venv myAuth
source myAuth/bin/activate
```

## 2) Install dependencies
```bash
pip install -r requirements.txt
```

## 3) Configure secrets (API key included via .env)
1. Copy `.env.example` to `.env`
2. Paste your API key in `.env`:

```env
GEMINI_API_KEY=PASTE_YOUR_API_KEY_HERE
```

> Do NOT hardcode keys in code. `.env` is ignored in real deployments.

## 4) Migrate DB
```bash
python manage.py migrate
```

## 5) Run
```bash
python manage.py runserver
```

### URLs
- Home: http://127.0.0.1:8000/
- SIP Plans: http://127.0.0.1:8000/sip-plans/
- My SIP: http://127.0.0.1:8000/my-plans/
- Chatbot: http://127.0.0.1:8000/chatbot/
