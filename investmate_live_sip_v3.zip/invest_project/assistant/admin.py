from django.contrib import admin
from .models import (
    InvestmentOption,
    InvestmentProduct,
    MarketSnapshot,
    TrainingRow,
    UserPlan,
    UserProfile,
    PlannerEntry,
    CalculatorHistory,
)

@admin.register(InvestmentOption)
class InvestmentOptionAdmin(admin.ModelAdmin):
    list_display = ("name", "risk_level", "min_monthly_amount", "expected_return")
    list_filter = ("risk_level",)
    search_fields = ("name",)

@admin.register(UserPlan)
class UserPlanAdmin(admin.ModelAdmin):
    list_display = ("id", "goal", "income", "expenses", "emi", "risk_score", "risk_band", "invest_amount", "created_at")
    list_filter = ("goal", "risk_band")
    search_fields = ("goal",)

admin.site.register(InvestmentProduct)
admin.site.register(MarketSnapshot)
admin.site.register(TrainingRow)
admin.site.register(UserProfile)
admin.site.register(PlannerEntry)
admin.site.register(CalculatorHistory)