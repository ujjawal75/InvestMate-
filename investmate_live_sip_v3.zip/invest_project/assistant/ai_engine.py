# assistant/ai_engine.py

def clamp(x, lo, hi):
    return max(lo, min(hi, x))


def compute_risk_score(income, expenses, emi, horizon_months, goal, risk_pref="Medium"):
    """
    Returns a score 0-100.
    Higher score => user can take more equity exposure.
    """
    income = max(float(income), 0)
    expenses = max(float(expenses), 0)
    emi = max(float(emi), 0)
    horizon_months = max(int(horizon_months), 0)

    disposable = income - expenses - emi
    disposable_ratio = disposable / max(income, 1)

    score = 50

    # Affordability / savings capacity
    if disposable_ratio >= 0.40:
        score += 20
    elif disposable_ratio >= 0.25:
        score += 10
    elif disposable_ratio < 0.10:
        score -= 20
    else:
        score -= 5

    # Horizon effect
    if horizon_months >= 60:
        score += 15
    elif horizon_months >= 24:
        score += 8
    elif horizon_months < 6:
        score -= 12

    # Goal effect
    if goal == "Emergency Fund":
        score -= 15
    elif goal == "Retirement":
        score += 8
    elif goal == "Wealth Creation":
        score += 10

    # User preference effect
    if risk_pref == "Low":
        score -= 8
    elif risk_pref == "High":
        score += 8

    return int(clamp(score, 0, 100))


def risk_band_from_score(score):
    if score < 35:
        return "Conservative"
    if score < 70:
        return "Balanced"
    return "Aggressive"


def optimize_allocation(risk_band, goal):
    """
    Returns allocation in percentages.
    """
    # Goal overrides
    if goal == "Emergency Fund":
        return {"equity": 10, "debt": 80, "gold": 10}

    if risk_band == "Conservative":
        return {"equity": 20, "debt": 70, "gold": 10}

    if risk_band == "Balanced":
        return {"equity": 55, "debt": 35, "gold": 10}

    # Aggressive
    return {"equity": 70, "debt": 20, "gold": 10}


def recommended_invest_amount(income, expenses, emi):
    """
    Suggest invest amount:
    - base: 20% of income
    - but never exceed disposable savings
    """
    income = max(float(income), 0)
    expenses = max(float(expenses), 0)
    emi = max(float(emi), 0)

    disposable = max(income - expenses - emi, 0)
    base = int(income * 0.20)
    return int(min(base, disposable)), int(disposable)


def generate_ai_insight(income, expenses, emi, horizon_months, goal, risk_band, alloc):
    disposable = max(float(income) - float(expenses) - float(emi), 0)
    if disposable <= 0:
        return "Your expenses/EMI are consuming most of your income. Reduce expenses or EMI first before investing."

    if goal == "Emergency Fund":
        return "AI recommends building an emergency fund first. Keep most of the allocation in safer debt instruments until you reach 3–6 months of expenses."

    if horizon_months < 12:
        return "Short horizon detected. AI is prioritizing stability (debt/gold) to reduce downside risk."

    if risk_band == "Aggressive":
        return "Your profile allows higher equity exposure. Stick to disciplined SIPs and avoid random stock picks without a learning plan."

    if risk_band == "Conservative":
        return "AI suggests a conservative mix. Focus on FD/RD + a small SIP to start wealth building safely."

    return "Balanced profile detected. A mix of Index/SIP + Debt + Gold can help you grow while controlling risk."
