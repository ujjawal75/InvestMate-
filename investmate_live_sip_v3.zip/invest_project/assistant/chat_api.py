import requests
from django.conf import settings

GEMINI_ENDPOINT = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent"

def gemini_reply(message: str) -> str | None:
    key = getattr(settings, "GEMINI_API_KEY", "") or ""
    if not key:
        return None

    prompt = (
        "You are InvestMate, a friendly investment assistant. "
        "Give short, practical answers. Avoid financial guarantees. "
        "If user asks for returns, explain assumptions.\n\n"
        f"User: {message}"
    )

    payload = {
        "contents": [{"parts": [{"text": prompt}]}],
        "generationConfig": {"temperature": 0.6, "maxOutputTokens": 220},
    }

    try:
        r = requests.post(f"{GEMINI_ENDPOINT}?key={key}", json=payload, timeout=20)
        if r.status_code != 200:
            return None
        data = r.json()
        # Parse response safely
        candidates = data.get("candidates") or []
        if not candidates:
            return None
        content = candidates[0].get("content") or {}
        parts = content.get("parts") or []
        if not parts:
            return None
        text = parts[0].get("text")
        if not text:
            return None
        return text.strip()
    except Exception:
        return None
