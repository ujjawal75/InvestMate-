def recommend_plan(income: int, risk: str):
    """
    Simple beginner-friendly logic:
    - invest 20% of income
    - split depends on risk level
    """

    invest = int(income * 0.20)

    if risk == "Low":
        split = [
            ("FD / RD", int(invest * 0.50)),
            ("Liquid / Debt Fund", int(invest * 0.30)),
            ("Gold (Digital/SGB)", invest - int(invest * 0.50) - int(invest * 0.30)),
        ]
        tips = [
            "Build Emergency Fund first (3–6 months expenses).",
            "Prefer safe instruments (FD/RD/Liquid).",
            "Avoid high-risk options until basics are clear."
        ]

    elif risk == "Medium":
        split = [
            ("Index Fund SIP", int(invest * 0.55)),
            ("Debt Fund / FD", int(invest * 0.25)),
            ("Gold (Digital/SGB)", invest - int(invest * 0.55) - int(invest * 0.25)),
        ]
        tips = [
            "Index funds are great for long-term simple growth.",
            "Keep some portion safe (FD/Debt) for stability.",
            "Stay consistent: SIP monthly, don’t panic in dips."
        ]

    else:  # High
        split = [
            ("Equity SIP", int(invest * 0.60)),
            ("Stocks (learning part)", int(invest * 0.25)),
            ("Gold (Digital/SGB)", invest - int(invest * 0.60) - int(invest * 0.25)),
        ]
        tips = [
            "High-risk means bigger ups/downs—don’t invest blindly.",
            "Use direct stocks only with learning + discipline.",
            "Diversify: SIP + some safety is still important."
        ]

    return invest, split, tips
