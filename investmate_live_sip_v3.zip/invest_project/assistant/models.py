from django.conf import settings
from django.db import models


class InvestmentOption(models.Model):
    RISK_CHOICES = [("Low", "Low"), ("Medium", "Medium"), ("High", "High")]

    name = models.CharField(max_length=120)
    risk_level = models.CharField(max_length=10, choices=RISK_CHOICES)
    min_monthly_amount = models.IntegerField(default=0)
    expected_return = models.CharField(max_length=50, blank=True)
    description = models.TextField(blank=True)

    def __str__(self):
        return f"{self.name} ({self.risk_level})"


class InvestmentProduct(models.Model):
    PRODUCT_CHOICES = [
        ("FD", "Fixed Deposit"),
        ("DEBT_FUND", "Debt Fund"),
        ("EQUITY_FUND", "Equity Mutual Fund"),
        ("INDEX_FUND", "Index Fund"),
        ("STOCK", "Stock"),
        ("GOLD", "Gold"),
        ("BOND", "Bond"),
        ("PPF", "PPF"),
        ("NPS", "NPS"),
        ("REAL_ESTATE", "Real Estate"),
    ]

    name = models.CharField(max_length=140)
    product_type = models.CharField(max_length=20, choices=PRODUCT_CHOICES)
    risk_level = models.IntegerField()
    liquidity_days = models.IntegerField(default=7)
    min_horizon_months = models.IntegerField(default=6)
    expense_ratio = models.FloatField(default=0.0)
    avg_return_1y = models.FloatField(default=0.0)
    avg_return_3y = models.FloatField(default=0.0)
    avg_return_5y = models.FloatField(default=0.0)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return self.name


class MarketSnapshot(models.Model):
    date = models.DateField(unique=True)
    inflation = models.FloatField()
    repo_rate = models.FloatField()
    market_volatility = models.FloatField()
    market_trend = models.IntegerField()

    def __str__(self):
        return str(self.date)


class TrainingRow(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)

    salary_monthly = models.IntegerField()
    expenses_monthly = models.IntegerField()
    risk_tolerance = models.IntegerField()
    goal_type = models.CharField(max_length=20)
    horizon_months = models.IntegerField()
    existing_savings = models.IntegerField(default=0)

    product_type = models.CharField(max_length=20)
    product_risk = models.IntegerField()
    liquidity_days = models.IntegerField()
    min_horizon_months = models.IntegerField()
    expense_ratio = models.FloatField()

    inflation = models.FloatField()
    repo_rate = models.FloatField()
    market_volatility = models.FloatField()
    market_trend = models.IntegerField()

    monthly_invest_amount = models.IntegerField()
    duration_months = models.IntegerField()
    realized_return_pct = models.FloatField()
    drawdown_pct = models.FloatField()
    success = models.IntegerField()

    def __str__(self):
        return f"Row {self.id}"


class UserPlan(models.Model):
    GOAL_CHOICES = [
        ("Emergency Fund", "Emergency Fund"),
        ("Education", "Education"),
        ("Marriage", "Marriage"),
        ("Retirement", "Retirement"),
        ("Wealth Creation", "Wealth Creation"),
    ]
    income = models.IntegerField()
    expenses = models.IntegerField()
    emi = models.IntegerField(default=0)
    goal = models.CharField(max_length=50, choices=GOAL_CHOICES)
    horizon_months = models.IntegerField(default=12)
    risk_score = models.IntegerField(default=0)
    risk_band = models.CharField(max_length=20, default="Balanced")
    invest_amount = models.IntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.goal} ({self.risk_band})"


class UserProfile(models.Model):
    RISK_CHOICES = [(1, "Low"), (2, "Low-Med"), (3, "Medium"), (4, "Med-High"), (5, "High")]
    GOAL_CHOICES = [
        ("EMERGENCY", "Emergency Fund"),
        ("LAND", "Buying Land"),
        ("MARRIAGE", "Daughter Marriage"),
        ("RETIREMENT", "Retirement"),
        ("WEALTH", "Wealth Growth"),
        ("EDUCATION", "Education"),
    ]

    name = models.CharField(max_length=120)
    salary_monthly = models.IntegerField()
    expenses_monthly = models.IntegerField()
    existing_savings = models.IntegerField(default=0)
    risk_tolerance = models.IntegerField(choices=RISK_CHOICES)
    goal_type = models.CharField(max_length=20, choices=GOAL_CHOICES)
    horizon_months = models.IntegerField()

    def __str__(self):
        return self.name


# ✅ Competition feature: Save user plan history after login
class PlannerEntry(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="planner_entries")
    income = models.FloatField()
    expenses = models.FloatField()
    emi = models.FloatField(default=0)
    goal = models.CharField(max_length=80)
    horizon_months = models.PositiveIntegerField()
    risk_pref = models.CharField(max_length=10)
    risk_band = models.CharField(max_length=10)
    recommended_invest = models.PositiveIntegerField()
    allocation_json = models.JSONField(default=dict, blank=True)
    insight = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.user} • {self.goal} • {self.created_at:%Y-%m-%d}"


class CalculatorHistory(models.Model):
    CALC_CHOICES = [
        ("sip", "SIP"),
        ("goal", "Goal"),
        ("lumpsum", "Lumpsum"),
    ]
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="calculator_history")
    calc_type = models.CharField(max_length=20, choices=CALC_CHOICES)
    payload = models.JSONField(default=dict, blank=True)
    summary = models.CharField(max_length=120, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.user} • {self.calc_type} • {self.created_at:%Y-%m-%d}"