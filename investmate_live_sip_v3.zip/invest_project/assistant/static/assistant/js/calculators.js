function fmtINR(n){
  if(!isFinite(n)) return "—";
  return "₹" + Math.round(n).toLocaleString('en-IN');
}

function sipFutureValue(pmt, ratePa, years){
  // Monthly compounding SIP annuity formula
  const r = (ratePa/100)/12;
  const n = Math.round(years*12);
  if(r === 0) return pmt*n;
  return pmt * (((Math.pow(1+r, n) - 1) / r) * (1+r));
}

function sipTimeToTarget(pmt, ratePa, target){
  const r = (ratePa/100)/12;
  if(target <= 0) return null;
  if(r === 0) return Math.ceil(target / pmt);

  // Binary search months (1..1200 = 100 years)
  let lo = 1, hi = 1200, ans = null;
  while(lo <= hi){
    const mid = Math.floor((lo+hi)/2);
    const fv = pmt * (((Math.pow(1+r, mid) - 1) / r) * (1+r));
    if(fv >= target){
      ans = mid;
      hi = mid - 1;
    }else{
      lo = mid + 1;
    }
  }
  return ans;
}

function goalSipNeeded(target, ratePa, years){
  const r = (ratePa/100)/12;
  const n = Math.round(years*12);
  if(r === 0) return target / n;
  // Rearranged annuity formula
  const denom = (((Math.pow(1+r, n) - 1) / r) * (1+r));
  return target / denom;
}

(function(){
  const sipBtn = document.getElementById('btnSipCalc');
  if(sipBtn){
    sipBtn.addEventListener('click', () => {
      const pmt = Number(document.getElementById('sipAmount').value || 0);
      const rate = Number(document.getElementById('sipRate').value || 0);
      const years = Number(document.getElementById('sipYears').value || 0);
      const target = Number(document.getElementById('sipTarget').value || 0);

      const invested = pmt * Math.round(years*12);
      const value = sipFutureValue(pmt, rate, years);
      const profit = value - invested;

      document.getElementById('sipInvested').textContent = fmtINR(invested);
      document.getElementById('sipValue').textContent = fmtINR(value);
      document.getElementById('sipProfit').textContent = fmtINR(profit);

      const payload = {pmt, rate, years, target, invested, value, profit};
      const hidden = document.getElementById('sipPayload');
      if(hidden) hidden.value = JSON.stringify(payload);

      const timeBox = document.getElementById('sipTargetTime');
      if(target && target > 0){
        const months = sipTimeToTarget(pmt, rate, target);
        if(months === null){
          timeBox.textContent = "Please enter a valid target.";
        }else{
          const y = Math.floor(months/12);
          const m = months%12;
          timeBox.textContent = `To reach ${fmtINR(target)}, it may take about ${y} years ${m} months (approx).`;
        }
      }else{
        timeBox.textContent = "Enter a target amount to estimate.";
      }
    });

    // auto-calc once
    sipBtn.click();
  }

  const goalBtn = document.getElementById('btnGoalCalc');
  if(goalBtn){
    goalBtn.addEventListener('click', () => {
      const target = Number(document.getElementById('goalTarget').value || 0);
      const years = Number(document.getElementById('goalYears').value || 0);
      const rate = Number(document.getElementById('goalRate').value || 0);

      const sip = goalSipNeeded(target, rate, years);
      const invested = sip * Math.round(years*12);

      document.getElementById('goalSip').textContent = fmtINR(sip);
      document.getElementById('goalInvested').textContent = fmtINR(invested);

      const payload = {target, years, rate, sip, invested};
      const hidden = document.getElementById('goalPayload');
      if(hidden) hidden.value = JSON.stringify(payload);
    });
    goalBtn.click();
  }
})();