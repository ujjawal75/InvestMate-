(function(){
  const chatBox = document.getElementById('chatBox');
  const form = document.getElementById('chatForm');
  const input = document.getElementById('chatInput');

  function addMsg(text, who){
    const wrap = document.createElement('div');
    wrap.className = 'chat-msg ' + (who === 'me' ? 'me' : 'bot');
    wrap.innerHTML = `<div class="bubble">${text}</div>`;
    chatBox.appendChild(wrap);
    chatBox.scrollTop = chatBox.scrollHeight;
  }

  addMsg("Hi 👋 I'm InvestMate. Ask me about SIP, budgeting, risk, or future goals.", "bot");

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const q = (input.value || '').trim();
    if(!q) return;

    addMsg(q, 'me');
    input.value = '';

    try{
      const res = await fetch('/chatbot/reply/', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({message: q})
      });
      const data = await res.json();
      addMsg(data.reply || "Sorry, I couldn't understand that.", 'bot');
    }catch(err){
      addMsg("Network error. Please try again.", 'bot');
    }
  });
})();