from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
    path("", views.home, name="home"),

    # Auth
    path("accounts/login/", auth_views.LoginView.as_view(template_name="registration/login.html"), name="login"),
    path("accounts/logout/", auth_views.LogoutView.as_view(), name="logout"),
    path("accounts/register/", views.register, name="register"),
    path("dashboard/", views.dashboard, name="dashboard"),

    # Tools
    path("sip/", views.sip_calculator, name="sip_calculator"),
    path("goal/", views.goal_calculator, name="goal_calculator"),
    path("save-calc/", views.save_calc, name="save_calc"),

    # Pages
    path("future-goals/", views.future_goals, name="future_goals"),

    # Chatbot
    path("chatbot/", views.chatbot, name="chatbot"),
    path("chatbot/reply/", views.chatbot_reply, name="chatbot_reply"),
]