from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django.http import JsonResponse, HttpResponseBadRequest
from django.shortcuts import redirect, render
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST
import json

from .ai_engine import (
    compute_risk_score,
    risk_band_from_score,
    optimize_allocation,
    recommended_invest_amount,
    generate_ai_insight,
)
from .models import PlannerEntry, CalculatorHistory
from .chat_api import gemini_reply
from sipplans.models import SavedSIPPlan, SIPInvestment


def home(request):
    context = {}

    if request.method == "POST":
        try:
            income = float(request.POST.get("income", 0))
            expenses = float(request.POST.get("expenses", 0))
            emi = float(request.POST.get("emi", 0) or 0)
            goal = request.POST.get("goal", "Wealth Creation")
            horizon = int(request.POST.get("horizon", 12))
            risk_pref = request.POST.get("risk_pref", "Medium")

            if income <= 0 or horizon <= 0 or expenses < 0 or emi < 0:
                context["error"] = "Please enter valid numbers (income > 0, horizon > 0)."
                return render(request, "assistant/home.html", context)

            risk_score = compute_risk_score(income, expenses, emi, horizon, goal, risk_pref)
            risk_band = risk_band_from_score(risk_score)
            alloc = optimize_allocation(risk_band, goal)
            invest_amt, disposable = recommended_invest_amount(income, expenses, emi)

            insight = generate_ai_insight(income, expenses, emi, horizon, goal, risk_band, alloc)

            context["result"] = {
                "risk_score": risk_score,
                "risk_band": risk_band,
                "alloc": alloc,
                "recommended_invest": int(invest_amt),
                "disposable": int(disposable),
                "goal": goal,
                "horizon": horizon,
                "risk_pref": risk_pref,
                "insight": insight,
            }

            # ✅ Save for logged-in users (competition feature)
            if request.user.is_authenticated:
                PlannerEntry.objects.create(
                    user=request.user,
                    income=income,
                    expenses=expenses,
                    emi=emi,
                    goal=goal,
                    horizon_months=horizon,
                    risk_pref=risk_pref,
                    risk_band=risk_band,
                    recommended_invest=int(invest_amt),
                    allocation_json=alloc,
                    insight=insight,
                )
                context["saved"] = True

        except Exception:
            context["error"] = "Something went wrong. Please enter correct numbers."

    return render(request, "assistant/home.html", context)


def future_goals(request):
    return render(request, "assistant/future_goals.html")


def sip_calculator(request):
    return render(request, "assistant/sip_calculator.html")


def goal_calculator(request):
    return render(request, "assistant/goal_calculator.html")


def chatbot(request):
    return render(request, "assistant/chatbot.html")


@login_required
def dashboard(request):
    plans = PlannerEntry.objects.filter(user=request.user)[:25]
    calcs = CalculatorHistory.objects.filter(user=request.user)[:25]
    sip_saved = SavedSIPPlan.objects.filter(user=request.user)[:25]
    my_sips = SIPInvestment.objects.filter(user=request.user)[:25]
    return render(request, "assistant/dashboard.html", {"plans": plans, "calcs": calcs, "sip_saved": sip_saved, "my_sips": my_sips})


def register(request):
    if request.user.is_authenticated:
        return redirect("dashboard")

    if request.method == "POST":
        form = UserCreationForm(request.POST)
        email = request.POST.get("email", "").strip()
        if form.is_valid():
            user = form.save(commit=False)
            if email:
                user.email = email
            user.save()
            login(request, user)
            messages.success(request, "Account created ✅")
            return redirect("dashboard")
        else:
            messages.error(request, "Please fix the errors below.")
    else:
        form = UserCreationForm()

    return render(request, "assistant/register.html", {"form": form})


@login_required
@require_POST
def save_calc(request):
    calc_type = request.POST.get("calc_type", "").strip()
    payload_raw = request.POST.get("payload", "{}")

    try:
        payload = json.loads(payload_raw or "{}")
    except Exception:
        return HttpResponseBadRequest("Invalid payload")

    summary = ""
    if calc_type == "sip":
        summary = f"SIP ₹{int(payload.get('pmt', 0))}/mo • {payload.get('years', 0)}y"
    elif calc_type == "goal":
        summary = f"Target ₹{int(payload.get('target', 0))} • {payload.get('years', 0)}y"
    else:
        summary = calc_type

    CalculatorHistory.objects.create(
        user=request.user,
        calc_type=calc_type,
        payload=payload,
        summary=summary[:120],
    )

    messages.success(request, "Saved to dashboard ✅")
    # redirect back
    referer = request.META.get("HTTP_REFERER") or "/"
    return redirect(referer)


@require_POST
@csrf_exempt
def chatbot_reply(request):
    # Simple rule-based replies (works offline). You can plug API later.
    try:
        data = json.loads(request.body.decode("utf-8"))
        raw = (data.get("message") or "").strip()
        msg = raw.lower().strip()
    except Exception:
        return JsonResponse({"reply": "Invalid request."})

    def contains(*words):
        return any(w in msg for w in words)

    if not msg:
        return JsonResponse({"reply": "Type something and I’ll help 😊"})

    # Try AI (if API key is configured). Fallback to offline rules.
    ai = gemini_reply(raw)
    if ai:
        return JsonResponse({"reply": ai})

    # Core intents
    if contains("sip"):
        return JsonResponse({"reply": "SIP (Systematic Investment Plan) means investing a fixed amount every month. It reduces risk via rupee‑cost averaging and works best for long-term goals."})

    if contains("risk"):
        return JsonResponse({"reply": "Risk depends on income stability, EMI/debt, time horizon and your comfort. Longer horizon usually allows higher equity allocation."})

    if contains("budget", "expenses", "saving"):
        return JsonResponse({"reply": "A simple rule: 50% needs, 30% wants, 20% savings/investments. First build an emergency fund (3–6 months expenses)."} )

    if contains("land", "plot"):
        return JsonResponse({"reply": "For buying land, keep the money safer as your purchase date gets near. Use a mix: short-term debt/liquid funds for near goals, and index/equity for long horizons."})

    if contains("marriage", "daughter"):
        return JsonResponse({"reply": "For marriage planning: decide target amount + time. If time is short (<3y), prefer safer options. If long-term (5–10y), combine index SIP + some debt for stability."})

    if contains("hello", "hi", "hey"):
        return JsonResponse({"reply": "Hi 👋 Tell me your goal and time (e.g., 10 lakh in 8 years), I’ll guide you."})

    return JsonResponse({"reply": "I can help with SIP, goal planning, budgeting and risk. Try asking: “Target 10 lakh in 7 years at 12% return — how much SIP?”"})