from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path("admin/", admin.site.urls),        # ✅ admin only once
    path("", include("assistant.urls")),
    path("", include("sipplans.urls")),
    # ✅ website pages + recommend
]