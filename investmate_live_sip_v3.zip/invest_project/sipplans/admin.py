from django.contrib import admin
from .models import SavedSIPPlan, SIPInvestment


@admin.register(SavedSIPPlan)
class SavedSIPPlanAdmin(admin.ModelAdmin):
    list_display = ("user", "scheme_name", "scheme_code", "latest_nav", "latest_nav_date", "created_at")
    search_fields = ("scheme_name", "scheme_code", "user__username")
    list_filter = ("created_at",)


@admin.register(SIPInvestment)
class SIPInvestmentAdmin(admin.ModelAdmin):
    list_display = ("user", "scheme_name", "scheme_code", "monthly_amount", "years", "expected_return", "created_at")
    search_fields = ("scheme_name", "scheme_code", "user__username")
    list_filter = ("created_at",)
