from django import forms


class SIPInvestmentForm(forms.Form):
    monthly_amount = forms.IntegerField(min_value=100, label="Monthly SIP Amount (₹)")
    years = forms.IntegerField(min_value=1, max_value=40, initial=5, label="Duration (years)")
    expected_return = forms.DecimalField(min_value=0, max_value=30, decimal_places=2, initial=12.00, label="Expected Return (% p.a.)")
