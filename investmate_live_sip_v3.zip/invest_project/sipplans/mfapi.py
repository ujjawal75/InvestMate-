import requests

BASE = "https://api.mfapi.in"

class MFAPIError(Exception):
    pass

def _get(url, params=None, timeout=15):
    r = requests.get(url, params=params or {}, timeout=timeout)
    if r.status_code != 200:
        raise MFAPIError(f"MFAPI request failed ({r.status_code})")
    return r.json()

def mf_search(query: str):
    return _get(f"{BASE}/mf/search", params={"q": query}, timeout=15)

def mf_latest(scheme_code: str):
    return _get(f"{BASE}/mf/{scheme_code}/latest", timeout=15)

def mf_history(scheme_code: str, start_date: str = None, end_date: str = None):
    params = {}
    if start_date: params["startDate"] = start_date
    if end_date: params["endDate"] = end_date
    return _get(f"{BASE}/mf/{scheme_code}", params=params, timeout=20)
