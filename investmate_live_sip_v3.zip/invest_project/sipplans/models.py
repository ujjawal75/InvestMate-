from django.db import models
from django.contrib.auth.models import User


class SavedSIPPlan(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="saved_sip_plans")
    scheme_code = models.CharField(max_length=20)
    scheme_name = models.CharField(max_length=255)
    fund_house = models.CharField(max_length=255, blank=True)
    latest_nav = models.DecimalField(max_digits=12, decimal_places=4, null=True, blank=True)
    latest_nav_date = models.CharField(max_length=30, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ("user", "scheme_code")

    def __str__(self):
        return f"{self.user.username} - {self.scheme_name}"


class SIPInvestment(models.Model):
    """Demo-safe 'investment' record.

    NOTE: This does NOT place real transactions. It's a user intent / plan stored for dashboard.
    Real investing requires a registered broker/RIA + regulated transaction rails.
    """

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="sip_investments")

    scheme_code = models.CharField(max_length=20)
    scheme_name = models.CharField(max_length=255)
    fund_house = models.CharField(max_length=255, blank=True)

    monthly_amount = models.PositiveIntegerField()  # INR
    years = models.PositiveIntegerField(default=5)
    expected_return = models.DecimalField(max_digits=5, decimal_places=2, default=12.00)  # % per year

    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} SIP ₹{self.monthly_amount}/mo in {self.scheme_code}"
