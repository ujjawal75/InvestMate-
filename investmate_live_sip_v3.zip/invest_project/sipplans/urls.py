from django.urls import path
from . import views

urlpatterns = [
    path("sip-plans/", views.sip_plan_search, name="sipplans_search"),
    path("sip-plans/<str:scheme_code>/", views.sip_plan_detail, name="sipplans_detail"),
    path("sip-plans/<str:scheme_code>/start/", views.start_sip, name="sip_start"),
    path("sip-plans/save/", views.save_sip_plan, name="sipplans_save"),
    path("my-plans/", views.my_saved_plans, name="my_saved_plans"),
]
