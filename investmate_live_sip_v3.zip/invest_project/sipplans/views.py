from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from django.views.decorators.http import require_POST

from .forms import SIPInvestmentForm
from .mfapi import mf_search, mf_latest, mf_history
from .models import SavedSIPPlan, SIPInvestment


# Curated list for "Live SIP Plans" homepage so users immediately see options.
# Scheme codes are stable identifiers.
TRENDING_SCHEMES = [
    # Index / large cap style
    (119551, "HDFC Index Fund - NIFTY 50 Plan - Direct Plan"),
    (120503, "SBI Bluechip Fund - Direct Plan - Growth"),
    (120828, "ICICI Prudential Bluechip Fund - Direct - Growth"),
    # Flexi / large & mid
    (118834, "Parag Parikh Flexi Cap Fund - Direct - Growth"),
    (122639, "Mirae Asset Large Cap Fund - Direct - Growth"),
    # Hybrid / balanced
    (119062, "HDFC Balanced Advantage Fund - Direct - Growth"),
]


def sip_plan_search(request):
    q = (request.GET.get("q") or "").strip()
    results = []
    trending = []
    error = None

    if q:
        try:
            data = mf_search(q)
            results = data.get("data", [])
        except Exception as e:
            error = str(e)
    else:
        # No search → show a default list of "Live SIP Plans".
        for code, fallback_name in TRENDING_SCHEMES:
            item = {
                "schemeCode": str(code),
                "schemeName": fallback_name,
                "nav": None,
                "date": "",
            }
            try:
                latest = mf_latest(str(code))
                if isinstance(latest, dict) and isinstance(latest.get("data"), list) and latest["data"]:
                    item["nav"] = latest["data"][0].get("nav")
                    item["date"] = latest["data"][0].get("date", "")
                meta = latest.get("meta") if isinstance(latest, dict) else None
                if isinstance(meta, dict) and meta.get("scheme_name"):
                    item["schemeName"] = meta.get("scheme_name")
            except Exception:
                pass
            trending.append(item)

    return render(
        request,
        "sipplans/search.html",
        {"q": q, "results": results, "trending": trending, "error": error},
    )


def sip_plan_detail(request, scheme_code):
    latest = None
    hist = None
    error = None

    chart_dates, chart_navs = [], []

    try:
        latest = mf_latest(str(scheme_code))
        # history can be large; keep last ~365 points for chart
        hist = mf_history(str(scheme_code))
        data = list((hist or {}).get("data", []))
        data.reverse()
        for row in data[-365:]:
            chart_dates.append(row.get("date"))
            try:
                chart_navs.append(float(row.get("nav")))
            except Exception:
                chart_navs.append(None)
    except Exception as e:
        error = str(e)

    # try to extract scheme name for UI
    scheme_name = ""
    try:
        meta = (hist or {}).get("meta")
        if isinstance(meta, dict):
            scheme_name = meta.get("scheme_name") or ""
    except Exception:
        pass

    return render(
        request,
        "sipplans/detail.html",
        {
            "scheme_code": scheme_code,
            "scheme_name": scheme_name,
            "latest": latest,
            "hist": hist,
            "error": error,
            "chart_dates": chart_dates,
            "chart_navs": chart_navs,
        },
    )


@require_POST
@login_required
def save_sip_plan(request):
    scheme_code = (request.POST.get("scheme_code") or "").strip()
    scheme_name = (request.POST.get("scheme_name") or "").strip()
    fund_house = (request.POST.get("fund_house") or "").strip()

    if not scheme_code or not scheme_name:
        messages.error(request, "Invalid scheme data.")
        return redirect("sipplans_search")

    latest_nav = None
    latest_nav_date = ""

    try:
        latest = mf_latest(scheme_code)
        # MFAPI latest response is usually {"data":[{"date":..,"nav":..}], ...}
        if isinstance(latest, dict) and isinstance(latest.get("data"), list) and latest["data"]:
            latest_nav = latest["data"][0].get("nav")
            latest_nav_date = latest["data"][0].get("date", "")
    except Exception:
        pass

    obj, created = SavedSIPPlan.objects.get_or_create(
        user=request.user,
        scheme_code=scheme_code,
        defaults={
            "scheme_name": scheme_name,
            "fund_house": fund_house,
            "latest_nav": latest_nav or None,
            "latest_nav_date": latest_nav_date,
        },
    )

    if created:
        messages.success(request, "Fund saved ✅")
    else:
        messages.info(request, "This fund is already saved.")

    return redirect("sipplans_detail", scheme_code=scheme_code)


@login_required
def start_sip(request, scheme_code):
    """Create a demo-safe SIP investment record for the logged-in user."""

    scheme_name = request.GET.get("name", "").strip()

    if request.method == "POST":
        form = SIPInvestmentForm(request.POST)
        if form.is_valid():
            SIPInvestment.objects.create(
                user=request.user,
                scheme_code=str(scheme_code),
                scheme_name=scheme_name or str(scheme_code),
                monthly_amount=form.cleaned_data["monthly_amount"],
                years=form.cleaned_data["years"],
                expected_return=form.cleaned_data["expected_return"],
            )
            messages.success(request, "SIP plan added to your dashboard ✅")
            return redirect("dashboard")
        else:
            messages.error(request, "Please fix the form errors.")
    else:
        form = SIPInvestmentForm(initial={"monthly_amount": 2000, "years": 5, "expected_return": 12.00})

    return render(
        request,
        "sipplans/start.html",
        {"scheme_code": scheme_code, "scheme_name": scheme_name, "form": form},
    )


@login_required
def my_saved_plans(request):
    plans = SavedSIPPlan.objects.filter(user=request.user).order_by("-created_at")
    my_sips = SIPInvestment.objects.filter(user=request.user).order_by("-created_at")
    return render(request, "sipplans/saved.html", {"plans": plans, "my_sips": my_sips})
